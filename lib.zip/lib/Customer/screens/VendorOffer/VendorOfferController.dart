
import 'package:get/get.dart';

class VendorOfferController extends GetxController{

}