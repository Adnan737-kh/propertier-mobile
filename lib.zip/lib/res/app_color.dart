
import 'package:flutter/material.dart';

class AppColor {

  static const Color blackColor = Color(0xFF000000);
}