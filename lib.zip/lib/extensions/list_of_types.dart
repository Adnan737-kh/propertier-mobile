class ListOfTypes {
  List<String> types = [
    "Offices",
    "Shops",
    "Flats",
    "Plots",
    "Guest House",
    "House",
    "Villa",
    "Plaza",
    "Food Court",
    "Building",
    "Warehouse",
    "Hall",
    "Factory",
    "Theatre",
    "Gym",
    "Marriage Hall",
    "Rooms",
  ];
}
