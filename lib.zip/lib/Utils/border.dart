import 'package:flutter/material.dart';

border({
  Color color = const Color(0xffF1F1F1),
  double width = 1,
}) {
  return Border.all(color: color, width: width);
}
