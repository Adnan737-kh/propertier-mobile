import 'package:get/get.dart';

class ActivityViewModel extends GetxController {}
