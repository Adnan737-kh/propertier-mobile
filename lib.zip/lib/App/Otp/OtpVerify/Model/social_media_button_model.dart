import 'package:flutter/foundation.dart';

class SocialMediaButtonModel {
  final String icon;
  final VoidCallback onTap;
  SocialMediaButtonModel({required this.icon, required this.onTap});
}
