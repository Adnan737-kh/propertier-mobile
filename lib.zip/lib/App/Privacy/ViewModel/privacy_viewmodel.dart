import 'package:get/get.dart';

class PrivacyViewModel extends GetxController {}
