class OnBoardingModel {
  final String imageUrl;
  final String title;
  OnBoardingModel({required this.title, required this.imageUrl});
}
