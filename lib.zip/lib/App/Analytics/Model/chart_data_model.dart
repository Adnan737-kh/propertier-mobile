class SalesData {
  SalesData(this.x, this.y);
  final String x;
  final double y;
}
