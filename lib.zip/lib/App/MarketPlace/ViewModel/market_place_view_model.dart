import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MarketPlaceViewModel extends GetxController {
  TextEditingController searchController = TextEditingController();
}
