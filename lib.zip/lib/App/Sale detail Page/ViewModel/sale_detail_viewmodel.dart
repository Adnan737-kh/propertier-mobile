import 'package:get/get.dart';

class SaleDetailViewModel extends GetxController {}
