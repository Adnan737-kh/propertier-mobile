import 'package:get/get.dart';

class FilesViewModel extends GetxController {}
