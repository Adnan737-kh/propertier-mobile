import 'package:get/get.dart';

class FilesDetailViewModel extends GetxController {}
