class TeamModel {
  String id;
  String salary;
  String name;
  String department;
  String status;
  TeamModel(
      {required this.id,
      required this.name,
      required this.salary,
      required this.department,
      required this.status});
}
