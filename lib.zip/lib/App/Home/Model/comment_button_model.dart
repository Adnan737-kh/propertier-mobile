import 'package:flutter/material.dart';

class CommentButtonModel {
  IconData icon;
  String title;
  CommentButtonModel({required this.icon, required this.title});
}
