class GridTileModel {
  final String title;
  final String iconLink;

  GridTileModel({required this.title, required this.iconLink});
}
