import 'package:get/get.dart';

class PolicyViewModel extends GetxController {}
