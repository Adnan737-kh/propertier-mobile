import 'package:get/get.dart';

class MarketingTeamEarningViewModel extends GetxController {}
