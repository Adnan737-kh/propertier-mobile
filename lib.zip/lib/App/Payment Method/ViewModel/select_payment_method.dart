import 'package:get/get.dart';

class SelectPaymentMethodViewModel extends GetxController {}
