import 'package:get/get.dart';

class TeamEarningViewModel extends GetxController {}
