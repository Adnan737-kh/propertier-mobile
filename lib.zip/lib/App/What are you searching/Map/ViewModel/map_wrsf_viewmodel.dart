import 'package:get/get.dart';

class MapWYRSFViewModel extends GetxController {}
